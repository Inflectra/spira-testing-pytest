# PyTest Extension for SpiraTest

This version of the plugin is compatible with Python 3.x and SpiraTest/SpiraTeam/SpiraPlan 6.+

The latest documentation for using this extension can be found at http://spiradoc.inflectra.com/Unit-Testing-Integration/Integrating-with-PyTest/