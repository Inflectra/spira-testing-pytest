# PyTest Extension for SpiraTest

This version of the plugin is compatible with Python 3.x

The latest documentation for using this extension
can be found at http://www.inflectra.com/Products/Documentation.aspx

The PDF guide contains details instructions for integrating SpiraTest
with a variety of automated testing tools including PyTest.

